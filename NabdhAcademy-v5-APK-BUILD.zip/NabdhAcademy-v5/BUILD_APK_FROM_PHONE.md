# بناء APK من الهاتف

هذا المشروع يحتوي على GitHub Actions جاهز لبناء APK سحابيًا، لذلك لا تحتاج Android Studio على الهاتف.

1. ارفع مجلد المشروع إلى مستودع GitHub جديد.
2. من Settings > Secrets and variables > Actions أضف:
   - SUPABASE_URL
   - SUPABASE_PUBLISHABLE_KEY
3. افتح Actions واختر **Build Nabdh Academy APK** ثم Run workflow.
4. بعد نجاح البناء افتح صفحة التشغيل، ومن Artifacts حمّل `nabdh-academy-debug-apk`.
5. فك الضغط وثبّت `app-debug.apk` على الهاتف.

ملاحظة: ملف APK الناتج Debug للتجربة والتثبيت. قبل النشر الرسمي على Google Play نحتاج توقيع Release وإعداد بيانات التطبيق النهائية.
