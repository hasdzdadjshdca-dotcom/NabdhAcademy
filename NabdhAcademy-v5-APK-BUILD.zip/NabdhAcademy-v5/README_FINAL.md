# نبض أكاديمي — نسخة V5

منصة Android تعليمية عربية RTL مرتبطة بـ Supabase.

## الموجود في هذه النسخة
- تسجيل دخول وإنشاء حساب عبر Supabase Auth.
- ملفات مستخدم وصلاحيات student / teacher / admin.
- عرض الدورات المنشورة من قاعدة البيانات.
- صفحة دورة ومحاضرات ومعاينات مجانية.
- طلب اشتراك/شراء محفوظ بحالة pending إلى أن يتم التحقق من الدفع.
- دورات الطالب المفعلة.
- لوحة مدرس لإنشاء دورة.
- Supabase Storage للفيديوهات الخاصة.
- روابط فيديو موقعة مؤقتًا + مشغل Media3/ExoPlayer.
- حفظ تقدم مشاهدة المحاضرات.
- RLS على الجداول والتخزين.

## إعداد Supabase
1. أنشئ مشروعًا في Supabase.
2. نفّذ `supabase_schema.sql` كاملًا في SQL Editor.
3. أنشئ Bucket باسم `course-videos` واجعله Private.
4. أنشئ Bucket باسم `course-covers` واجعله Public.
5. في `local.properties`:

```properties
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

لا تضع Service Role/Secret Key داخل APK.

## الدفع
النسخة تسجل طلب الاشتراك كـ `pending`. ربط بوابة دفع عراقية فعلية يحتاج مزودًا تختاره أنت، ثم Webhook/Edge Function موثوق يتحقق من الدفع ويحوّل الاشتراك إلى `active`. لا تعتمد على التطبيق وحده لتأكيد الدفع.

## البناء
افتح المشروع في Android Studio، اعمل Gradle Sync ثم Run أو Build APK.

هذه البيئة الحالية لا تحتوي Android SDK/Gradle كاملًا، لذلك لا يمكنني إخراج APK binary فعلي من داخل المحادثة؛ ملف المشروع المصدر جاهز للبناء.
