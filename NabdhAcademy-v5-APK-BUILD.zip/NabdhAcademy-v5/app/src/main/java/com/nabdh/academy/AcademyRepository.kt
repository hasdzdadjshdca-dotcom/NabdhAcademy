package com.nabdh.academy

import io.github.jan.supabase.auth.providers.Email
import io.github.jan.supabase.auth.user.UserInfo
import io.github.jan.supabase.postgrest.from
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlin.time.Duration.Companion.minutes

@Serializable
data class ProfileRow(
    val id: String,
    @SerialName("full_name") val fullName: String = "",
    val phone: String? = null,
    val role: String = "student"
)

@Serializable
data class CourseRow(
    val id: String,
    @SerialName("teacher_id") val teacherId: String,
    @SerialName("category_id") val categoryId: String? = null,
    val title: String,
    val description: String = "",
    @SerialName("price_iqd") val priceIqd: Int = 0,
    @SerialName("cover_url") val coverUrl: String? = null,
    @SerialName("is_published") val isPublished: Boolean = false
)

@Serializable
data class LessonRow(
    val id: String,
    @SerialName("course_id") val courseId: String,
    val title: String,
    val description: String = "",
    @SerialName("video_path") val videoPath: String? = null,
    @SerialName("duration_seconds") val durationSeconds: Int = 0,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("is_preview") val isPreview: Boolean = false
)

@Serializable
data class ProfileInsert(
    val id: String,
    @SerialName("full_name") val fullName: String,
    val phone: String? = null,
    val role: String = "student"
)

@Serializable
data class CourseInsert(
    @SerialName("teacher_id") val teacherId: String,
    @SerialName("category_id") val categoryId: String? = null,
    val title: String,
    val description: String,
    @SerialName("price_iqd") val priceIqd: Int,
    @SerialName("is_published") val isPublished: Boolean = false
)

@Serializable
data class LessonInsert(
    @SerialName("course_id") val courseId: String,
    val title: String,
    val description: String = "",
    @SerialName("video_path") val videoPath: String? = null,
    @SerialName("duration_seconds") val durationSeconds: Int = 0,
    @SerialName("sort_order") val sortOrder: Int = 0,
    @SerialName("is_preview") val isPreview: Boolean = false
)

@Serializable
data class EnrollmentRow(
    val id: String,
    @SerialName("student_id") val studentId: String,
    @SerialName("course_id") val courseId: String,
    val status: String,
    @SerialName("amount_iqd") val amountIqd: Int
)

@Serializable
data class EnrollmentInsert(
    @SerialName("student_id") val studentId: String,
    @SerialName("course_id") val courseId: String,
    val status: String = "pending",
    @SerialName("amount_iqd") val amountIqd: Int
)

class AcademyRepository {
    private val db get() = SupabaseProvider.client

    suspend fun signIn(email: String, password: String) {
        db.auth.signInWith(Email) {
            this.email = email.trim()
            this.password = password
        }
    }

    suspend fun signUp(email: String, password: String, fullName: String) {
        db.auth.signUpWith(Email) {
            this.email = email.trim()
            this.password = password
            data = kotlinx.serialization.json.buildJsonObject {
                put("full_name", fullName.trim())
            }
        }
        val user = db.auth.currentUserOrNull()
        if (user != null) ensureProfile(user, fullName)
    }

    suspend fun signOut() = db.auth.signOut()

    suspend fun currentUser(): UserInfo? = db.auth.currentUserOrNull()

    suspend fun ensureProfile(user: UserInfo, name: String = "") {
        db.from("profiles").upsert(
            ProfileInsert(user.id, name.ifBlank { user.email ?: "" }),
            onConflict = "id"
        )
    }

    suspend fun profile(): ProfileRow? {
        val id = db.auth.currentUserOrNull()?.id ?: return null
        return db.from("profiles").select {
            filter { eq("id", id) }
        }.decodeList<ProfileRow>().firstOrNull()
    }

    suspend fun teacherCourses(): List<CourseRow> {
        val id = db.auth.currentUserOrNull()?.id ?: return emptyList()
        return db.from("courses").select { filter { eq("teacher_id", id) } }.decodeList()
    }

    suspend fun courses(): List<CourseRow> = db.from("courses").select {
        filter { eq("is_published", true) }
    }.decodeList()

    suspend fun myCourses(): List<CourseRow> {
        val userId = db.auth.currentUserOrNull()?.id ?: return emptyList()
        val ids = db.from("enrollments").select {
            filter { eq("student_id", userId); eq("status", "active") }
        }.decodeList<EnrollmentRow>().map { it.courseId }
        if (ids.isEmpty()) return emptyList()
        return db.from("courses").select {
            filter { isIn("id", ids) }
        }.decodeList()
    }

    suspend fun lessons(courseId: String): List<LessonRow> = db.from("lessons").select {
        filter { eq("course_id", courseId) }
    }.decodeList()

    suspend fun requestEnrollment(course: CourseRow) {
        val userId = db.auth.currentUserOrNull()?.id ?: error("يجب تسجيل الدخول أولاً")
        db.from("enrollments").upsert(
            EnrollmentInsert(userId, course.id, "pending", course.priceIqd),
            onConflict = "student_id,course_id"
        )
    }

    suspend fun createCourse(title: String, description: String, priceIqd: Int, categoryId: String? = null) {
        val teacherId = db.auth.currentUserOrNull()?.id ?: error("يجب تسجيل الدخول")
        db.from("courses").insert(CourseInsert(teacherId, categoryId, title, description, priceIqd))
    }

    suspend fun createLesson(courseId: String, title: String, videoPath: String?, preview: Boolean) {
        db.from("lessons").insert(LessonInsert(courseId, title, videoPath = videoPath, isPreview = preview))
    }

    suspend fun uploadVideo(path: String, bytes: ByteArray): String {
        db.storage.from("course-videos").upload(path, bytes) { upsert = false }
        return path
    }

    suspend fun signedVideoUrl(path: String): String =
        db.storage.from("course-videos").createSignedUrl(path, 60.minutes)

    suspend fun markLessonProgress(lessonId: String, seconds: Int, completed: Boolean) {
        val userId = db.auth.currentUserOrNull()?.id ?: return
        @Serializable data class Progress(
            @SerialName("student_id") val studentId: String,
            @SerialName("lesson_id") val lessonId: String,
            @SerialName("watched_seconds") val watchedSeconds: Int,
            val completed: Boolean
        )
        db.from("lesson_progress").upsert(
            Progress(userId, lessonId, seconds, completed),
            onConflict = "student_id,lesson_id"
        )
    }
}
