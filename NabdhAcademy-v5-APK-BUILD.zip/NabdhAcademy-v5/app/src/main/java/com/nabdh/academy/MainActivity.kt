package com.nabdh.academy

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF12B8A6)
private val Bg = Color(0xFFF5F7FA)
private val White = Color.White
private val repo = AcademyRepository()

data class SessionState(val logged: Boolean = false, val name: String = "", val role: String = "student")

data class UiError(val message: String? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NabdhAcademyApp() }
    }
}

@Composable
fun NabdhAcademyApp() {
    val scope = rememberCoroutineScope()
    var session by remember { mutableStateOf(SessionState()) }
    var screen by remember { mutableStateOf("home") }
    var selectedCourse by remember { mutableStateOf<CourseRow?>(null) }
    var selectedLesson by remember { mutableStateOf<LessonRow?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching {
            val user = repo.currentUser()
            if (user != null) {
                repo.ensureProfile(user)
                val profile = repo.profile()
                session = SessionState(true, profile?.fullName ?: user.email.orEmpty(), profile?.role ?: "student")
            }
        }.onFailure { error = it.message }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Teal, background = Bg)) {
        if (error != null) {
            AlertDialog(onDismissRequest = { error = null }, confirmButton = { TextButton({ error = null }) { Text("حسنًا") } }, title = { Text("تنبيه") }, text = { Text(error.orEmpty()) })
        }
        when (screen) {
            "login" -> LoginScreen(
                onBack = { screen = "home" },
                onDone = { s -> session = s; screen = "home" }
            )
            "course" -> selectedCourse?.let { course ->
                CourseScreen(course, session.logged, onBack = { screen = "home" }, onOpenLesson = { lesson -> selectedLesson = lesson; screen = "lesson" }, onRequest = {
                    scope.launch { runCatching { repo.requestEnrollment(course) }.onSuccess { error = "تم إرسال طلب الاشتراك. بعد تأكيد الدفع ستصبح الدورة متاحة." }.onFailure { error = it.message } }
                })
            }
            "lesson" -> selectedLesson?.let { lesson -> LessonPlayerScreen(lesson, onBack = { screen = "course" }, onProgress = { seconds, done -> scope.launch { repo.markLessonProgress(lesson.id, seconds, done) } }) }
            "teacher" -> TeacherDashboard(onBack = { screen = "home" }, onChanged = { error = it })
            "admin" -> AdminScreen(onBack = { screen = "home" })
            else -> Scaffold(
                containerColor = Bg,
                bottomBar = {
                    NavigationBar(containerColor = White) {
                        listOf("الرئيسية", "دوراتي", "حسابي").forEachIndexed { i, label ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂", "▣", "●")[i], fontSize = 21.sp) }, label = { Text(label) })
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        0 -> HomeScreen(onOpen = { selectedCourse = it; screen = "course" })
                        1 -> MyCoursesScreen(session.logged, onOpen = { selectedCourse = it; screen = "course" }, onLogin = { screen = "login" })
                        else -> AccountScreen(session, onLogin = { screen = "login" }, onLogout = { scope.launch { repo.signOut(); session = SessionState() } }, onTeacher = { screen = "teacher" }, onAdmin = { screen = "admin" })
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onOpen: (CourseRow) -> Unit) {
    var courses by remember { mutableStateOf<List<CourseRow>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        runCatching { repo.courses() }.onSuccess { courses = it }.onFailure { error = it.message }.also { loading = false }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Column { Text("نبض أكاديمي", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Navy); Text("طريقك إلى التفوق", color = Color.Gray) } }
        item { Surface(RoundedCornerShape(20.dp), color = Navy, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text("تعلّم، اختبر، وتابع تقدمك", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("فيديوهات • ملازم • اختبارات • تقدم دراسي", color = White.copy(.85f)) } } }
        item { OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("ابحث عن دورة أو مدرس") }, shape = RoundedCornerShape(16.dp)) }
        item { Text("الأقسام", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf("رياضيات", "فيزياء", "كيمياء", "أحياء", "عربي").forEach { Surface(RoundedCornerShape(14.dp), color = White, tonalElevation = 2.dp) { Text(it, Modifier.padding(10.dp), fontWeight = FontWeight.SemiBold) } } } }
        item { Text("الدورات المنشورة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy) }
        if (loading) item { CircularProgressIndicator() }
        if (error != null) item { Text("تعذر تحميل الدورات: ${error}", color = MaterialTheme.colorScheme.error) }
        items(courses.filter { search.isBlank() || it.title.contains(search, true) || it.description.contains(search, true) }) { CourseCard(it, onOpen) }
    }
}

@Composable
fun CourseCard(c: CourseRow, onOpen: (CourseRow) -> Unit) {
    Surface(RoundedCornerShape(18.dp), color = White, tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().clickable { onOpen(c) }) {
        Column(Modifier.padding(16.dp)) {
            Text(if (c.priceIqd == 0) "مجانية" else "${c.priceIqd} د.ع", color = Teal, fontWeight = FontWeight.Bold)
            Text(c.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(c.description, color = Color.Gray, maxLines = 3)
        }
    }
}

@Composable
fun CourseScreen(course: CourseRow, logged: Boolean, onBack: () -> Unit, onOpenLesson: (LessonRow) -> Unit, onRequest: () -> Unit) {
    var lessons by remember(course.id) { mutableStateOf<List<LessonRow>>(emptyList()) }
    var loading by remember(course.id) { mutableStateOf(true) }
    LaunchedEffect(course.id) { runCatching { repo.lessons(course.id) }.onSuccess { lessons = it.sortedBy { l -> l.sortOrder } }.also { loading = false } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("‹ رجوع", color = Teal, modifier = Modifier.clickable { onBack() }); Text(course.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy); Text(course.description, color = Color.Gray) }
        item {
            Surface(RoundedCornerShape(18.dp), color = White, tonalElevation = 2.dp) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (course.priceIqd == 0) "دورة مجانية" else "السعر: ${course.priceIqd} د.ع", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    if (!logged) Button({ onRequest() }, Modifier.fillMaxWidth()) { Text("سجل الدخول للاشتراك") }
                    else Button({ onRequest() }, Modifier.fillMaxWidth()) { Text(if (course.priceIqd == 0) "الاشتراك بالدورة" else "طلب الاشتراك والدفع") }
                }
            }
        }
        item { Text("المحاضرات", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy) }
        if (loading) item { CircularProgressIndicator() }
        items(lessons) { lesson ->
            Surface(RoundedCornerShape(14.dp), color = White, modifier = Modifier.fillMaxWidth().clickable { if (lesson.isPreview) onOpenLesson(lesson) }) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (lesson.isPreview) "▶" else "🔒", fontSize = 20.sp); Spacer(Modifier.width(12.dp)); Column { Text(lesson.title, fontWeight = FontWeight.Bold); Text(if (lesson.isPreview) "معاينة مجانية" else "متاح بعد تفعيل الدورة", color = Color.Gray) }
                }
            }
        }
    }
}

@Composable
fun LessonPlayerScreen(lesson: LessonRow, onBack: () -> Unit, onProgress: (Int, Boolean) -> Unit) {
    val context = LocalContext.current
    var url by remember(lesson.id) { mutableStateOf<String?>(null) }
    var loading by remember(lesson.id) { mutableStateOf(true) }
    LaunchedEffect(lesson.videoPath) {
        if (lesson.videoPath != null) runCatching { repo.signedVideoUrl(lesson.videoPath) }.onSuccess { url = it }.also { loading = false } else loading = false
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("‹ رجوع", color = Teal, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.height(12.dp)); Text(lesson.title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(12.dp))
        if (loading) CircularProgressIndicator()
        else if (url == null) Surface(RoundedCornerShape(18.dp), color = Navy, modifier = Modifier.fillMaxWidth().height(230.dp)) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا يوجد فيديو لهذه المحاضرة بعد", color = White) } }
        else VideoView(url!!)
        Spacer(Modifier.height(16.dp)); Text("بعد المشاهدة اضغط لإكمال المحاضرة.", color = Color.Gray); Spacer(Modifier.height(12.dp)); Button({ onProgress(lesson.durationSeconds, true) }, Modifier.fillMaxWidth()) { Text("تمت مشاهدة المحاضرة ✓") }
    }
}

@Composable
fun VideoView(url: String) {
    val context = LocalContext.current
    val player = remember(url) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(Uri.parse(url))); prepare() } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(230.dp))
}

@Composable
fun MyCoursesScreen(logged: Boolean, onOpen: (CourseRow) -> Unit, onLogin: () -> Unit) {
    var courses by remember { mutableStateOf<List<CourseRow>>(emptyList()) }
    LaunchedEffect(logged) { if (logged) runCatching { repo.myCourses() }.onSuccess { courses = it } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("دوراتي", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy) }
        if (!logged) item { Button(onLogin, Modifier.fillMaxWidth()) { Text("سجل الدخول لعرض دوراتك") } }
        if (logged && courses.isEmpty()) item { Text("لا توجد دورات مفعلة حاليًا.", color = Color.Gray) }
        items(courses) { CourseCard(it, onOpen) }
    }
}

@Composable
fun AccountScreen(session: SessionState, onLogin: () -> Unit, onLogout: () -> Unit, onTeacher: () -> Unit, onAdmin: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("حسابي", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy) }
        if (!session.logged) item { Surface(RoundedCornerShape(18.dp), color = White) { Column(Modifier.padding(20.dp)) { Text("أهلاً بك في نبض أكاديمي", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("سجل الدخول لحفظ الدورات والتقدم.", color = Color.Gray); Spacer(Modifier.height(12.dp)); Button(onLogin, Modifier.fillMaxWidth()) { Text("تسجيل الدخول / إنشاء حساب") } } } }
        else {
            item { Surface(RoundedCornerShape(18.dp), color = White) { Column(Modifier.padding(20.dp)) { Text(session.name, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("نوع الحساب: ${session.role}", color = Color.Gray) } } }
            if (session.role == "teacher") item { Button(onTeacher, Modifier.fillMaxWidth()) { Text("لوحة المدرس") } }
            if (session.role == "admin") item { Button(onAdmin, Modifier.fillMaxWidth()) { Text("لوحة الإدارة") } }
            item { OutlinedButton(onLogout, Modifier.fillMaxWidth()) { Text("تسجيل الخروج") } }
        }
    }
}

@Composable
fun LoginScreen(onBack: () -> Unit, onDone: (SessionState) -> Unit) {
    val scope = rememberCoroutineScope(); var signup by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("‹ رجوع", color = Teal, modifier = Modifier.clickable { onBack() }); Spacer(Modifier.height(20.dp)); Text("نبض أكاديمي", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Navy); Text(if (signup) "إنشاء حساب" else "تسجيل الدخول", fontSize = 22.sp); Spacer(Modifier.height(18.dp))
        if (signup) { OutlinedTextField(name, { name = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(10.dp)) }
        OutlinedTextField(email, { email = it }, label = { Text("البريد الإلكتروني") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(10.dp)); OutlinedTextField(password, { password = it }, label = { Text("كلمة المرور") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Spacer(Modifier.height(12.dp))
        if (error != null) Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
        Button(enabled = !busy, onClick = { scope.launch { busy = true; runCatching { if (signup) repo.signUp(email, password, name) else repo.signIn(email, password); val user = repo.currentUser() ?: error("إذا كان تأكيد البريد مفعلًا، افتح بريدك الإلكتروني أولًا."); repo.ensureProfile(user, name); val p = repo.profile(); onDone(SessionState(true, p?.fullName ?: user.email.orEmpty(), p?.role ?: "student")) }.onFailure { error = it.message }.also { busy = false } } }, Modifier.fillMaxWidth()) { Text(if (busy) "جارٍ التنفيذ..." else if (signup) "إنشاء الحساب" else "دخول") }
        TextButton({ signup = !signup }, Modifier.fillMaxWidth()) { Text(if (signup) "لدي حساب بالفعل" else "إنشاء حساب جديد") }
    }
}

@Composable
fun TeacherDashboard(onBack: () -> Unit, onChanged: (String?) -> Unit) {
    val scope = rememberCoroutineScope(); var courses by remember { mutableStateOf<List<CourseRow>>(emptyList()) }; var title by remember { mutableStateOf("") }; var description by remember { mutableStateOf("") }; var price by remember { mutableStateOf("0") }; var showAdd by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { runCatching { repo.teacherCourses() }.onSuccess { courses = it }.onFailure { onChanged(it.message) } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("‹ رجوع", color = Teal, modifier = Modifier.clickable { onBack() }); Text("لوحة المدرس", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy) }
        item { Button({ showAdd = true }, Modifier.fillMaxWidth()) { Text("➕ إنشاء دورة") } }
        items(courses) { CourseCard(it, {}) }
        if (showAdd) item { Surface(RoundedCornerShape(18.dp), color = White) { Column(Modifier.padding(16.dp)) { Text("دورة جديدة", fontSize = 20.sp, fontWeight = FontWeight.Bold); OutlinedTextField(title, { title = it }, label = { Text("اسم الدورة") }, Modifier.fillMaxWidth()); OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, Modifier.fillMaxWidth()); OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("السعر بالدينار") }, Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); Button({ scope.launch { runCatching { repo.createCourse(title, description, price.toIntOrNull() ?: 0) }.onSuccess { showAdd = false; onChanged("تم إنشاء الدورة") }.onFailure { onChanged(it.message) } } }, Modifier.fillMaxWidth()) { Text("حفظ") } } } }
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) { Column(Modifier.fillMaxSize().padding(16.dp)) { Text("‹ رجوع", color = Teal, modifier = Modifier.clickable { onBack() }); Text("لوحة الإدارة", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Navy); Spacer(Modifier.height(16.dp)); Text("إدارة المدرسين والطلاب والدورات والطلبات والمدفوعات والإشعارات تكون عبر سياسات RLS وصلاحيات admin في Supabase.", color = Color.Gray) } }
