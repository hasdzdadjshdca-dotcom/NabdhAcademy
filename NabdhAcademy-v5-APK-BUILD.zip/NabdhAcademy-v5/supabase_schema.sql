-- نبض أكاديمي: initial Supabase schema
create extension if not exists pgcrypto;

create type public.app_role as enum ('student','teacher','admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.app_role not null default 'student',
  avatar_url text,
  created_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  title text not null,
  description text not null default '',
  price_iqd integer not null default 0 check (price_iqd >= 0),
  cover_url text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  description text not null default '',
  video_path text,
  duration_seconds integer not null default 0,
  sort_order integer not null default 0,
  is_preview boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  status text not null default 'active' check (status in ('pending','active','cancelled')),
  amount_iqd integer not null default 0,
  purchased_at timestamptz not null default now(),
  unique(student_id, course_id)
);

create table public.lesson_progress (
  student_id uuid not null references public.profiles(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  progress_seconds integer not null default 0,
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key(student_id, lesson_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete restrict,
  amount_iqd integer not null check(amount_iqd >= 0),
  provider text,
  provider_reference text,
  status text not null default 'pending' check(status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);

insert into public.categories(name) values
 ('رياضيات'),('فيزياء'),('كيمياء'),('أحياء'),('عربي'),('إنكليزي')
on conflict do nothing;

-- Helper functions for RLS
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;
create or replace function public.is_teacher() returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role in ('teacher','admin'));
$$;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.orders enable row level security;

create policy "profiles own read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles own update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "categories public read" on public.categories for select to anon, authenticated using (true);

create policy "published courses public read" on public.courses for select to anon, authenticated using (is_published = true or teacher_id = auth.uid() or public.is_admin());
create policy "teacher creates own courses" on public.courses for insert to authenticated with check (teacher_id = auth.uid() and public.is_teacher());
create policy "teacher updates own courses" on public.courses for update to authenticated using (teacher_id = auth.uid() or public.is_admin()) with check (teacher_id = auth.uid() or public.is_admin());
create policy "teacher deletes own courses" on public.courses for delete to authenticated using (teacher_id = auth.uid() or public.is_admin());

create policy "published course lessons read" on public.lessons for select to anon, authenticated using (
  is_preview = true or exists(select 1 from public.courses c where c.id = course_id and (c.is_published = true and (c.teacher_id = auth.uid() or exists(select 1 from public.enrollments e where e.course_id = c.id and e.student_id = auth.uid() and e.status = 'active'))))
  or exists(select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid())
  or public.is_admin()
);
create policy "teacher manages own lessons" on public.lessons for all to authenticated using (
  exists(select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid()) or public.is_admin()
) with check (
  exists(select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid()) or public.is_admin()
);

create policy "students read own enrollments" on public.enrollments for select to authenticated using (student_id = auth.uid() or public.is_admin());
create policy "students create pending enrollment" on public.enrollments for insert to authenticated with check (student_id = auth.uid());

create policy "students manage own progress" on public.lesson_progress for all to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());
create policy "students read own orders" on public.orders for select to authenticated using (student_id = auth.uid() or public.is_admin());

-- Profile is created after sign-up by the app/backend. For production, prefer a trusted trigger or Edge Function.

-- Storage buckets: create them from Dashboard or uncomment if your project permits SQL bucket creation.
-- insert into storage.buckets (id, name, public) values ('course-covers','course-covers',true) on conflict do nothing;
-- insert into storage.buckets (id, name, public) values ('course-videos','course-videos',false) on conflict do nothing;

-- Production hardening: automatically create a student profile after sign-up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create policy "admins update enrollments" on public.enrollments
for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "teachers read own enrollments" on public.enrollments
for select to authenticated
using (
  student_id = auth.uid() or public.is_admin() or exists (
    select 1 from public.courses c where c.id = course_id and c.teacher_id = auth.uid()
  )
);

-- Storage policies. Create the two buckets in Supabase Storage first.
-- course-videos must remain private; course-covers can be public.
create policy "teachers upload course videos" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'course-videos' and public.is_teacher()
);
create policy "teachers update course videos" on storage.objects
for update to authenticated
using (bucket_id = 'course-videos' and public.is_teacher())
with check (bucket_id = 'course-videos' and public.is_teacher());
create policy "teachers delete course videos" on storage.objects
for delete to authenticated
using (bucket_id = 'course-videos' and public.is_teacher());
create policy "students read enrolled course videos" on storage.objects
for select to authenticated
using (
  bucket_id = 'course-videos' and (
    public.is_admin()
    or public.is_teacher()
    or exists (
      select 1 from public.enrollments e
      where e.student_id = auth.uid()
        and e.status = 'active'
        and e.course_id::text = (storage.foldername(name))[1]
    )
  )
);
create policy "public read course covers" on storage.objects
for select to anon, authenticated
using (bucket_id = 'course-covers');
create policy "teachers upload course covers" on storage.objects
for insert to authenticated
with check (bucket_id = 'course-covers' and public.is_teacher());
